<!DOCTYPE html>
<html>
<head>
 <title>Display Routine</title>
 <style>
  table 
  {
   border-collapse: collapse;
   width: 100%;
   color: #588c7e;
   font-family: monospace;
   font-size: 25px;
   text-align: left;
   font-family:"Verdana";
   text-align: center;
  } 
  th 
  {
   background-color: #588c7e;
   color: white;
  }
  h1{
    font-family: "Arial";
    font-size: 50px;
     color: slategrey;
  }
  tr:nth-child(even) {background-color: #f2f2f2; }
 </style>
</head>
<body style="background-color: lavender">
  <h1>The table contents are displayed below:</h1>

 <table>
 <tr>
  <th>Time<br><br></th> 
  <th>Date<br><br></th> 
  <th>Room No<br><br></th>
  <th>Exam ID<br><br></th>
 </tr>
 <?php
$conn = mysqli_connect("localhost", "root", "", "student_result");

  if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
  } 
  
  $sql = "SELECT Time1, Date1, Room_No, Exam_Id FROM routine";
  $result = $conn->query($sql);
  if ($result->num_rows > 0)
   {
   
   while($row = $result->fetch_assoc())
    {
    echo "<tr><td>" . $row["Time1"]. "</td><td>" .$row["Date1"]. "</td><td>"
    . $row["Room_No"]. "<br></td><td>" . $row["Exam_Id"]. "</td></tr>";
    }
    echo "</table>";
   
    }
else 
  { 
    echo "0 results"; 
  }
$conn->close();
?>
</table>
</body>
</html>