<html>
<head>
    <title>DELETE RESULT</title>
</head>
<style>
input[type=text] {
    width: 110px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 9px;
    font-size: 16px;
    background-color: white;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 25px 20px 22px 10px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
    font-weight: bold;
    font-size: 30px;
}
input[type=text]:focus {
    width: 60%;
}
b{
	font-size: 20px;
	color: white;
	font-family: "verdana";
}
body {background: url("https://ak8.picdn.net/shutterstock/videos/1337908/thumb/9.jpg") no-repeat;
background-size:cover;}
</style>
<body><h1>
    <center> <h2>
<font style:"border: 15px dashed #cc66ff" FACE="Arial"COLOR="red"SIZE=25 align=center>
DELETE RESULT</font>
</h2></center>
<br>
<centre><b>
    <FONT FACE="Arial" size=5 COLOR="black">
    <Form ACTION="deleteresult.php"METHOD="POST">
        ENTER SUBJECT ID:<input type="text" name="t1" required><br><BR>
        <input type="submit" name="submit" value="SUBMIT">
    <input type="reset" value="RESET"><br></BR></FONT>
    </center></b></form>
    </h1>

        <?php

$host="localhost";
$user="root";
$password="";
$con= new mysqli($host,$user,$password,"student_result");      // here mysql is the database name
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
	$a=$_POST['t1'];

	if($a!="")
		{
			$sql1 = "select * from result where Sub_Id='$a'";
			$result = mysqli_query($con,$sql1);
			if(mysqli_num_rows($result)>0){
			$sql3="delete from result where Sub_Id='$a'";   // student is the table name
			mysqli_query($con,$sql3);
			echo "<b>Exam Deleted Successfully</b>";
		}else{
			echo "<b>$a does not Exist!</b>";
		}
			}else{
				echo "<b>Sub_Id Field is Empty</b>";
			}

$con->close();
 }
?>

</body>
</html>