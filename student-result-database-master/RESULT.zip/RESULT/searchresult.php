<html>
<head>
    <title>Search Result</title>
</head>
<style>
    table{
             border-collapse: collapse;
             width: 60%;
             padding: 150px;
             margin-left: 280px;

     } s
    th, td {
             text-align: center;
             padding: 8px;
             
            }
    tr:nth-child(even) 
    {
    	background-color: #f2f2f2;
        font-family: "arial";
        font-weight: bold;
        
    }
    th {
    background-color: mediumslateblue;
    color: white;
    font-family:  "verdana";
    font-weight: bold;
    
}
input[type=text] {
    width: 110px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 9px;
    font-size: 16px;
    background-color: white;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 25px 20px 22px 10px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
    font-weight: bold;
    font-size: 30px;
}
input[type=text]:focus {
    width: 60%;
}
div{
	font-family: "verdana";
	font-weight: bold;
	font-size: 30px;
	font-style: bold;
	margin-left:25px;
	margin-top: 35px;
}
.btn{
	background-color:green;
    color: white;
    padding: 16px 20px;
    margin: 8px 20px 20px 50px;
    border-radius: 21px;
    cursor: pointer;
    width: 10%;
    opacity: 0.5;
    align-content: center;
    font-family: "verdana";
    font-weight: bold;
}
.btn:hover {
    opacity: 1;
}
b{
	font-family: "verdana";
	background-color: lightcyan;
    color: black;
    margin-left:80px;
    border-radius: 8px;
    text-align: center;
    font-size: 30px;
    width: 85%;
    
}
p{
	font-family: "verdana";
	background-color: lightcyan;
    color: black;
    margin-top:4px;
    border-radius: 8px;
    text-align: center;
    font-size: 30px;
    margin-left:80px;
    width: 35%;
}
</style>
<body style="background-color: lavender">
	<form action="searchresult.php" method="post">
		<div>Enter Subject ID:<input type="text" name="subid"><br></div>
		<br><br>
		<button type="submit" value ="Find" class="btn">SEARCH</button>
	</form>
<?php
$host="localhost";
$user="root";
$password="";
$con= new mysqli($host,$user,$password,"student_result");
if ($con->connect_error) {
		    die("Connection failed: " . $con->connect_error);
		}
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
	$n=$_POST['subid'];
	echo "<b><br>The entered Subject ID is $n and the corresponding table is shown below:<br><br></b>";
	
	$sql="select * from result where Sub_Id='$n'";

				$result = $con->query($sql);

			if ($result->num_rows > 0) {
		    echo "<br><br><br><br><table><tr><th>SUBJECT ID</th><th>SUBJECT NAME</th><th><br>GRADE<br></br></th><th><br>USN<br></br></th></tr>";
		   		    while($row = $result->fetch_assoc()) {
		       echo "<tr><td>" . $row["Sub_Id"]. "</td><td>" .$row["Sub_Name"]. "</td><td><br>"
              . $row["Grade"]. "<br></br></td><td><br>"
              . $row["USN_No"]. "<br></br></td></tr>";
		    }
		    echo "</table>";
		} else {
		    echo "<p>No such Subject ID exists. Please enter correct Subject ID</p>";
		}
		}

		$con->close();
?>

</body>
</html>