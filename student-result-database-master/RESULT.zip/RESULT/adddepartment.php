 <?php
    if(isset($_POST['dno']) && isset($_POST['dname']) && isset($_POST['dlocation'])):
    $Dept_No = $_POST['dno'];
    $Dept_Name = $_POST['dname'];
    $Dept_Location = $_POST['dlocation'];

    $link = new mysqli('localhost','root','','student_result');

    if($link->connect_error)
        die('connection error: '.$link->connect_error);

    $sql3 = "INSERT INTO department(Dept_No, Dept_Name, Dept_Location) VALUES('".$Dept_No."', '".$Dept_Name."', '".$Dept_Location."')";

      

    $result = $link->query($sql3); 

    if($result > 0):
        echo 'Successfully posted';
    else:
        echo 'Unable to post';
    endif;

    $link->close();
    die();
    endif; 
?>