<html>
<head>
    <title>DELETE ROUTINE</title>
</head>
<style>
input[type=text] {
    width: 110px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 9px;
    font-size: 16px;
    background-color: white;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 25px 20px 22px 10px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
    font-weight: bold;
    font-size: 30px;
}
input[type=text]:focus {
    width: 60%;
}
b{
	font-size: 20px;
	color: white;
	font-family: "verdana";
}
body {background: url("https://images.pexels.com/photos/33602/books-student-study-education.jpg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260") no-repeat;
background-size:cover;}
</style>
<body><h1>
    <center> <h2>
<font style:"border: 15px dashed #cc66ff" FACE="Arial"COLOR="red"SIZE=25 align=center>
DELETE ROUTINE</font>
</h2></center>
<br>
<centre><b>
    <FONT FACE="Arial" size=5 COLOR="black">
    <Form ACTION="deleteroutine.php"METHOD="POST">
        ENTER EXAM ID:<input type="text" name="t1" required><br><BR>
        <input type="submit" name="submit" value="SUBMIT">
    <input type="reset" value="RESET"><br></BR></FONT>
    </center></b></form>
    </h1>

        <?php

$host="localhost";
$user="root";
$password="";
$con= new mysqli($host,$user,$password,"student_result");      // here mysql is the database name
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
	$a=$_POST['t1'];

	if($a!="")
		{
			$sql1 = "select * from routine where Exam_Id='$a'";
			$result = mysqli_query($con,$sql1);
			if(mysqli_num_rows($result)>0){
			$sql3="delete from routine where Exam_Id='$a'";   // student is the table name
			mysqli_query($con,$sql3);
			echo "<b>Routine Deleted Successfully</b>";
		}else{
			echo "<b>$a does not Exist!</b>";
		}
			}else{
				echo "<b>Exam_Id Field is Empty</b>";
			}

$con->close();
 }
?>

</body>
</html>