 <?php
    if(isset($_POST['examid']) && isset($_POST['year1']) && isset($_POST['semester'])&& isset($_POST['subid'])):
    $Exam_Id = $_POST['examid'];
    $Year1 = $_POST['year1'];
    $Semester = $_POST['semester'];
    $Sub_Id = $_POST['subid'];

    $link = new mysqli('localhost','root','','student_result');

    if($link->connect_error)
        die('connection error: '.$link->connect_error);

    $sql3 = "INSERT INTO exam(Exam_Id, Year1, Semester, Sub_Id) VALUES('".$Exam_Id."', '".$Year1."', '".$Semester."', '".$Sub_Id."')";

      

    $result = $link->query($sql3); 

    if($result > 0):
        echo 'Successfully posted';
    else:
        echo 'Unable to post';
    endif;

    $link->close();
    die();
    endif; 
?>