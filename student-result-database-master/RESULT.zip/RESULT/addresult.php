 <?php
    if(isset($_POST['subid']) && isset($_POST['subname']) && isset($_POST['grade'])&& isset($_POST['usn'])):
    $Sub_Id = $_POST['subid'];
    $Sub_Name = $_POST['subname'];
    $Grade = $_POST['grade'];
    $USN_No = $_POST['usn'];

    $link = new mysqli('localhost','root','','student_result');

    if($link->connect_error)
        die('connection error: '.$link->connect_error);

    $sql3 = "INSERT INTO result(Sub_Id, Sub_Name, Grade, USN_No) VALUES('".$Sub_Id."', '".$Sub_Name."', '".$Grade."', '".$USN_No."')";

      

    $result = $link->query($sql3); 

    if($result > 0):
        echo 'Successfully posted';
    else:
        echo 'Unable to post';
    endif;

    $link->close();
    die();
    endif; 
?>