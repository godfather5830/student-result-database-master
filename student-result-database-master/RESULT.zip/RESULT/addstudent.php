 <?php
    if(isset($_POST['usn']) && isset($_POST['name']) && isset($_POST['phone'])&& isset($_POST['department'])):
    $USN_No = $_POST['usn'];
    $Name = $_POST['name'];
    $Phone_No = $_POST['phone'];
    $Dept_No = $_POST['department'];

    $link = new mysqli('localhost','root','','student_result');

    if($link->connect_error)
        die('connection error: '.$link->connect_error);

    $sql3 = "INSERT INTO student(USN_No, Name, Phone_No, Dept_No) VALUES('".$USN_No."', '".$Name."', '".$Phone_No."', '".$Dept_No."')";

      

    $result = $link->query($sql3); 

    if($result > 0):
        echo 'Successfully posted';
    else:
        echo 'Unable to post';
    endif;

    $link->close();
    die();
    endif; 
?>