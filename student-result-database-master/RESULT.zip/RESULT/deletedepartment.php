<html>
<head>
    <title>DELETE DEPARTMENT</title>
</head>
<style> 
body {background: url("https://images.pexels.com/photos/533189/pexels-photo-533189.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260") no-repeat;
background-size:cover;}
</style>
<body><h1>
    <center> <h2>
<font style:"border: 15px dashed #cc66ff" FACE="Arial"COLOR="red"SIZE=25 align=center>
DELETE DEPARTMENT</font>
</h2></center>
<br>
<centre><b>
    <FONT FACE="Arial" size=5 COLOR="white">
    <Form ACTION="deletedepartment.php"METHOD="POST">
        ENTER DEPT NO:<input type="text" name="t1" required><br><BR>
        <input type="submit" name="submit" value="SUBMIT">
    <input type="reset" value="RESET"><br></BR></FONT>
    </center></b></form>
    </h1>

        <?php

$host="localhost";
$user="root";
$password="";
$con= new mysqli($host,$user,$password,"student_result");      // here mysql is the database name
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
	$a=$_POST['t1'];

	if($a!="")
		{
			$sql1 = "select * from department where Dept_No='$a'";
			$result = mysqli_query($con,$sql1);
			if(mysqli_num_rows($result)>0){
			$sql3="delete from department where Dept_No='$a'";   // student is the table name
			mysqli_query($con,$sql3);
			echo "Department Deleted Successfully";
		}else{
			echo "$a does not Exist!";
		}
			}else{
				echo "Dept_No Field is Empty";
			}

$con->close();
 }
?>

</body>
</html>