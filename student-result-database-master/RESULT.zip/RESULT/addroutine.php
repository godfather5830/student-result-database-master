 <?php
    if(isset($_POST['time1']) && isset($_POST['date1']) && isset($_POST['roomno'])&& isset($_POST['examid'])):
    $Time1 = $_POST['time1'];
    $Date1 = $_POST['date1'];
    $Room_No = $_POST['roomno'];
    $Exam_Id = $_POST['examid'];

    $link = new mysqli('localhost','root','','student_result');

    if($link->connect_error)
        die('connection error: '.$link->connect_error);

    $sql3 = "INSERT INTO routine(Time1, Date1, Room_No, Exam_Id) VALUES('".$Time1."', '".$Date1."', '".$Room_No."', '".$Exam_Id."')";

      

    $result = $link->query($sql3); 

    if($result > 0):
        echo 'Successfully posted';
    else:
        echo 'Unable to post';
    endif;

    $link->close();
    die();
    endif; 
?>