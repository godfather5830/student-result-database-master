<!DOCTYPE html>
<html>
<head>
 <title>Display Result</title>
 <style>
  table 
  {
   border-collapse: collapse;
   width: 100%;
   color: #588c7e;
   font-family: monospace;
   font-size: 25px;
   text-align: left;
   font-family:"Verdana";
   text-align: center;
  } 
  th 
  {
   background-color: #588c7e;
   color: white;
  }
  h1{
    font-family: "Arial";
    font-size: 50px;
     color: slategrey;
  }
  tr:nth-child(even) {background-color: #f2f2f2; }
 </style>
</head>
<body style="background-color: lavender">
  <h1>The table contents are displayed below:</h1>

 <table>
 <tr>
  <th>Subject ID<br><br></th> 
  <th>Subject Name<br><br></th> 
  <th>Grade<br><br></th>
  <th>USN<br><br></th>
 </tr>
 <?php
$conn = mysqli_connect("localhost", "root", "", "student_result");

  if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
  } 
  
  $sql = "SELECT Sub_Id, Sub_Name, Grade, USN_No FROM result";
  $result = $conn->query($sql);
  if ($result->num_rows > 0)
   {
   
   while($row = $result->fetch_assoc())
    {
    echo "<tr><td>" . $row["Sub_Id"]. "</td><td>" .$row["Sub_Name"]. "</td><td>"
    . $row["Grade"]. "<br></td><td>" . $row["USN_No"]. "</td></tr>";
    }
    echo "</table>";
   
    }
else 
  { 
    echo "0 results"; 
  }
$conn->close();
?>
</table>
</body>
</html>