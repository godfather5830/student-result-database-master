<!DOCTYPE html>
<html>
<head>
 <title>Display Department</title>
 <style>
  table 
  {
   border-collapse: collapse;
   width: 100%;
   color: #588c7e;
   font-family: monospace;
   font-size: 25px;
   text-align: left;
   font-family:"Verdana";
   text-align: center;
  } 
  th 
  {
   background-color: #588c7e;
   color: white;
  }
  h1{
    font-family: "Arial";
    font-size: 50px;
     color: slategrey;
  }
  tr:nth-child(even) {background-color: #f2f2f2; }
 </style>
</head>
<body style="background-color: lavender">
  <h1>The table contents are displayed below:</h1>
 <table>
 <tr>
  <th><br>Dept No<br><br></th> 
  <th><br>Dept Name<br><br></th> 
  <th><br>Dept Location<br><br></th>
  <br><br>
 </tr>
 <?php
$conn = mysqli_connect("localhost", "root", "", "student_result");

  if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
  } 
  
  $sql = "SELECT Dept_No, Dept_Name, Dept_Location FROM department";
  $result = $conn->query($sql);
  if ($result->num_rows > 0)
   {
   
   while($row = $result->fetch_assoc())
    {
    echo "<tr><td>" . $row["Dept_No"]. "</td><td>" .$row["Dept_Name"]. "</td><td><br>"
    . $row["Dept_Location"]. "<br></br></td></tr>";
    }
    echo "</table>";
   
    }
else 
  { 
    echo "0 results"; 
  }
$conn->close();
?>
</table>
</body>
</html>