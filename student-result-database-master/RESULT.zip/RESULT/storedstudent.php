<html>
<body>
<style>
body{
  background: url("https://images.pexels.com/photos/239548/pexels-photo-239548.jpeg?cs=srgb&dl=adult-blur-business-239548.jpg&fm=jpg") no-repeat;
  background-size: cover;
}
table, th, td {
    border: 1px solid black;
    background-color: lavenderblush;
    padding: 4px 11px;
    border-radius: 7px;
}
b{
  color: snow;
  font-size: 40px;
  font-family: Arial;
}
</style>
<center>
<?php

$host="localhost";
$user="root";
$password="";
$con= new mysqli($host,$user,$password,"student_result");
echo " <b>Creating stored procedure</b><br>";

$sql3="create procedure display1() select * from student";
mysqli_query($con,$sql3);
echo "<b>Procedure  created successfully</b><br>";


echo "<b> Calling Stored Procedure</b><br>";
if ($result = mysqli_query($con,"call display1()"))
   {
      echo "<table>";
      echo "<tr><th>USN_No</th><th>Name</th><th>Phone_No</th><th>Dept_No</th></tr>";
      while($row = mysqli_fetch_assoc($result))
      {
      echo "<tr><td>".$row["USN_No"]."</td><td>".$row["Name"]."</td><td>".$row["Phone_No"]."</td><td>".$row["Dept_No"]."</td></tr>";
      }
      echo "</table>";
      }
      else {
	  		    echo "0 results";
	  		}

	$con->close();
		?>
</center>
</body>
</html>